import java.rmi.*;
import java.rmi.server.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.concurrent.ExecutionException;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.TextMessage;
import javax.naming.NamingException;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import com.mysql.jdbc.Connection;

public class JPoker24GameServer extends UnicastRemoteObject implements Count {

	private static final String DB_HOST = "localhost";
	private static final String DB_USER = "twentyfour";
	private static final String DB_PASS = "twentyfour";
	private static final String DB_NAME = "twentyfour";
	
	private JMSHelper jmsHelper;
	
	public static void main(String[] args) {
		try {
			JPoker24GameServer app = new JPoker24GameServer();
			System.setSecurityManager(new SecurityManager());
			Naming.rebind("Counter", app);
			System.out.println("Service registered");
			app.start();
		} catch(Exception e) {
			System.err.println("Exception thrown: "+e);
		}
	}
	
	private String[] gamers = new String[]{"","","",""};
	long timeUsed=System.currentTimeMillis();
	
	private void start() throws JMSException, InterruptedException, ExecutionException, SQLException {
		MessageConsumer queueReader = jmsHelper.createQueueReader();
		MessageProducer topicSender = jmsHelper.createTopicSender();

		int count=0;
		long starttime=System.currentTimeMillis();
		while(true) {
			
			Message m = receiveMessage(queueReader);
			
			if (((TextMessage) m).getText().contains("Ans= ")) {
				String a = (String) ((TextMessage) m).getText();
				timeUsed=System.currentTimeMillis();
				validate(a);
			} else {
		        count++;
				System.out.println(count);
				gamers[count-1] = ((TextMessage) m).getText();
				
				if (count==1) 
					starttime = System.currentTimeMillis();
				
				if (count>3) {
					char[] cards = new char[]{'A','2','3','4','5','6','7','8','9','X','J','Q','K'};
					int card1=-1, card2=-1, card3=-1, card4=-1;
					card1 = new Random().nextInt(cards.length);
					while (card2==-1 || card2==card1) card2 = new Random().nextInt(cards.length);
					while (card3==-1 || card3==card1 || card3==card2) card3 = new Random().nextInt(cards.length);
					while (card4==-1 || card4==card1 || card4==card2 || card4==card3) card4 = new Random().nextInt(cards.length);
					Message jmsMessage = jmsHelper.createMessage(cards[card1]+","+cards[card2]+","+cards[card3]+","+cards[card4]);
					jmsMessage.setStringProperty("gamer1", gamers[0]);
					jmsMessage.setStringProperty("gamer2", gamers[1]);
					jmsMessage.setStringProperty("gamer3", gamers[2]);
					jmsMessage.setStringProperty("gamer4", gamers[3]);
					broadcastMessage(topicSender, jmsMessage);
					count=0;
				}
				
				if (count>1) {
					if (System.currentTimeMillis()-starttime > 10*1000) {
						char[] cards = new char[]{'A','2','3','4','5','6','7','8','9','X','J','Q','K'};
						int card1=-1, card2=-1, card3=-1, card4=-1;
						card1 = new Random().nextInt(cards.length);
						while (card2==-1 || card2==card1) card2 = new Random().nextInt(cards.length);
						while (card3==-1 || card3==card1 || card3==card2) card3 = new Random().nextInt(cards.length);
						while (card4==-1 || card4==card1 || card4==card2 || card4==card3) card4 = new Random().nextInt(cards.length);
						Message jmsMessage = jmsHelper.createMessage(cards[card1]+","+cards[card2]+","+cards[card3]+","+cards[card4]);
//						Message jmsMessage = jmsHelper.createMessage("A,2,3,4");
						jmsMessage.setStringProperty("gamer1", gamers[0]);
						jmsMessage.setStringProperty("gamer2", gamers[1]);
						jmsMessage.setStringProperty("gamer3", gamers[2]);
						jmsMessage.setStringProperty("gamer4", gamers[3]);
						broadcastMessage(topicSender, jmsMessage);
						count=0;
					}
				}
			}
		}
	}
	
	public Message receiveMessage(MessageConsumer queueReader) throws JMSException {
		try {
	        TextMessage jmsMessage = (TextMessage) queueReader.receive();
//	        System.out.println(jmsMessage);
	        return jmsMessage;
	    } catch(JMSException e) {
	        System.err.println("Failed to receive message "+e);
	        throw e;
	    }
	}
	public void broadcastMessage(MessageProducer topicSender, Message jmsMessage) throws JMSException {
		try {
			topicSender.send(jmsMessage);
			System.out.println("broadcast message sent.");
	    } catch(JMSException e) {
	        System.err.println("Failed to boardcast message "+e);
	        throw e;
	    }

	}

	private Connection conn;
	public JPoker24GameServer() throws RemoteException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, NamingException, JMSException {
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		conn = (Connection) DriverManager.getConnection("jdbc:mysql://"+DB_HOST+"/"+DB_NAME+"?user="+DB_USER+"&password="+DB_PASS);
		System.out.println("Database connection successful.");
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM OnlineUser");
		stmt.executeUpdate();
		
		jmsHelper = new JMSHelper();

	}

	/* for logout */
	public String count(String name) throws RemoteException {
		try {
			PreparedStatement stmt = conn.prepareStatement("DELETE FROM OnlineUser WHERE name = ?");
			stmt.setString(1, name);
			int rows = stmt.executeUpdate();
			if(rows > 0) {
				System.out.println("Record of "+name+" removed");
			} else {
				System.out.println(name+" not found!");
			}
		} catch (SQLException | IllegalArgumentException e) {
			System.err.println("Error inserting record: "+e);
		}
		
		return "ok";
	}

	/* for login */
	public String count(String name, String pw) throws RemoteException {
		try {
			String password;
			PreparedStatement stmt = conn.prepareStatement("SELECT name, password FROM UserInfo WHERE name = ?");
			stmt.setString(1, name);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				password = rs.getString(2);
			} else {
				return "invalid name";
			}
			
			if (password.equals(pw)) {
				PreparedStatement stmt2 = conn.prepareStatement("SELECT name FROM OnlineUser WHERE name = ?");
				stmt2.setString(1, name);
				ResultSet rs2 = stmt2.executeQuery();
				if(rs2.next()) {
					return "multiple";
				} else {
					PreparedStatement stmt3 = conn.prepareStatement("INSERT INTO OnlineUser (name) VALUES (?)");
					stmt3.setString(1, name);
					stmt3.execute();
					System.out.println("OnlineUser record created");
				}
			} else {
				return "invalid pw";
			}
			
		} catch (SQLException | IllegalArgumentException e) {
			System.err.println("Error inserting record: "+e);
		}
		
		return "ok";
	}
	
	/* for register */
	public String count(String name, String pw, String confirm_pw) throws RemoteException {
		try {
			
			PreparedStatement stmt = conn.prepareStatement("SELECT name FROM UserInfo WHERE name = ?");
			stmt.setString(1, name);
			
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				return "duplicated";
			} else {
				PreparedStatement stmt2 = conn.prepareStatement("INSERT INTO UserInfo (name, password, won, played, average) VALUES (?, ?, ?, ?, ?)");
				stmt2.setString(1, name);
				stmt2.setString(2, pw);
				stmt2.setInt(3, 0);
				stmt2.setInt(4, 0);
				stmt2.setInt(5, 0);
				stmt2.execute();
				System.out.println("UserInfo record created");
				PreparedStatement stmt3 = conn.prepareStatement("INSERT INTO OnlineUser (name) VALUES (?)");
				stmt3.setString(1, name);
				stmt3.execute();
				System.out.println("OnlineUser record created");
			}		    	
			
		} catch (SQLException | IllegalArgumentException e) {
			System.err.println("Error inserting record: "+e);
		}
		
		return "ok";
	}
	
	/* to get game players' info */
	public String count(String g1, String g2, String g3, String g4) throws RemoteException {
		String info = "";
		
		try {	
			PreparedStatement stmt = conn.prepareStatement("SELECT * FROM UserInfo WHERE (name = ? OR name = ? OR name = ? OR name = ?)");
			stmt.setString(1, g1);
			stmt.setString(2, g2);
			stmt.setString(3, g3);
			stmt.setString(4, g4);
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				info=info+rs.getString(1)+","+rs.getString(3)+","+rs.getString(4)+","+rs.getString(5)+","+rs.getString(6)+";";
			}
			
		} catch (SQLException | IllegalArgumentException e) {
			System.err.println("Error getting record: "+e);
		}
		return info;
	}
	
	/* for leader board */
	public String count() throws RemoteException {
		String info = "";
		try {	
			PreparedStatement stmt = conn.prepareStatement("SELECT * FROM UserInfo ORDER BY won DESC, average");
			ResultSet rs = stmt.executeQuery();
			
			int count=0;
			while (rs.next()) {
				info=info+rs.getString(1)+","+rs.getString(3)+","+rs.getString(4)+","+rs.getString(5)+","+rs.getString(6)+";";
				try {
					PreparedStatement stmt2 = conn.prepareStatement("UPDATE UserInfo SET ranking = ? WHERE name = ?");
					stmt2.setInt(1,++count);
					stmt2.setString(2,rs.getString(1));
					stmt2.executeUpdate();
				} catch (SQLException e) {
					System.err.println("Error: "+e);
				}
				
			}
			
		} catch (SQLException | IllegalArgumentException e) {
			System.err.println("Error getting record: "+e);
		}
		return info;
	}

	/* for answer validation */
	public void validate(String input) throws JMSException, SQLException{
		
		MessageProducer topicSender = jmsHelper.createTopicSender();
		
		boolean flag=true;
		
		/* check operands */
		System.out.println("0. "+input);
		String[] inputs = input.split(";");
		System.out.println("1. "+inputs[0]);
		System.out.println("1b. "+inputs[1]);
		System.out.println("1c. "+inputs[2]);
		System.out.println("1d. "+inputs[3]);
		String ans = inputs[0].replaceAll(" |Ans= ", "");
		System.out.println("2. "+ans);
		String temp = ans.replaceAll("[*+-/)(]", "");
		System.out.println("3. "+temp);
		String[] card = inputs[1].split(",");
		String cards = card[0]+card[1]+card[2]+card[3];
		if ((temp.length() == cards.length()) && temp.contains(card[0]) && temp.contains(card[1]) && temp.contains(card[2]) && temp.contains(card[3])) {
			System.out.println("operands matched");
			flag=true;
		} else {
			System.out.println("Cards not matched");
			flag=false;
			
			Message jmsMessage = jmsHelper.createMessage("Wrong ans: Cards not matched");
			jmsMessage.setStringProperty("gamer1", inputs[2]);
			jmsMessage.setStringProperty("gamer2", "");
			jmsMessage.setStringProperty("gamer3", "");
			jmsMessage.setStringProperty("gamer4", "");
			broadcastMessage(topicSender, jmsMessage);
		}
		
		/* check operators */
		String operators = ans.replaceAll("[\\dAJKQ]","");
		char[] os = operators.toCharArray();
		System.out.println("4. "+operators);
		for (char o : os) {
			if (o == '+' || o == '-' || o == '*' || o == '/' || o == '(' || o == ')') {
			}
			else {
				System.out.println("Illegal operators");
				flag=false;
								
				Message jmsMessage = jmsHelper.createMessage("Wrong ans: Illegal operators");
				jmsMessage.setStringProperty("gamer1", inputs[2]);
				jmsMessage.setStringProperty("gamer2", "");
				jmsMessage.setStringProperty("gamer3", "");
				jmsMessage.setStringProperty("gamer4", "");
				broadcastMessage(topicSender, jmsMessage);
				
				break;
			}
		}
		
		if (flag) {
			System.out.println(flag);
			ScriptEngine engine = new ScriptEngineManager().getEngineByExtension("js");	 
	        try {
	            // Evaluate the expression
	        	String expr = ans;
	        	expr = expr.replaceAll("A", "1");
	        	expr = expr.replaceAll("J", "11");
	        	expr = expr.replaceAll("Q", "12");
	        	expr = expr.replaceAll("K", "13");
	        	System.out.println(expr);
	            Object result = engine.eval(expr);
	            System.out.println(ans + " = " + result);
	            
	            if (result.toString().equals("24")) {
	            	String[] gs = inputs[3].split(",");
	            	Message jmsMessage = jmsHelper.createMessage("Correct ans: "+inputs[2]+";"+ans);
					jmsMessage.setStringProperty("gamer1", gs[0]);
					jmsMessage.setStringProperty("gamer2", gs[1]);
	            	if (gs.length==2) {
						jmsMessage.setStringProperty("gamer3", "");
						jmsMessage.setStringProperty("gamer4", "");
	            	} else if (gs.length==3) {
						jmsMessage.setStringProperty("gamer3", gs[2]);
						jmsMessage.setStringProperty("gamer4", "");
	            	} else if (gs.length==4) {
						jmsMessage.setStringProperty("gamer3", gs[2]);
						jmsMessage.setStringProperty("gamer4", gs[3]);
	            	}
					broadcastMessage(topicSender, jmsMessage);
					
					PreparedStatement stmt = conn.prepareStatement("SELECT won, played, average, name FROM UserInfo WHERE (name = ? OR name = ? OR name = ? OR name = ?)");
					stmt.setString(1, gs[0]);
					stmt.setString(2, gs[1]);
					if (gs.length==2) {
						stmt.setString(3, "");
						stmt.setString(4, "");
	            	} else if (gs.length==3) {
	            		stmt.setString(3, gs[2]);
						stmt.setString(4, "");
	            	} else if (gs.length==4) {
	            		stmt.setString(3, gs[2]);
						stmt.setString(4, gs[3]);
	            	}
					ResultSet rs = stmt.executeQuery();
					while(rs.next()) {
						if (rs.getString(4).equals( inputs[2] )) {
							PreparedStatement stmt2 = conn.prepareStatement("UPDATE UserInfo SET won = ?, played = ?, average = ? WHERE name = ?");
							stmt2.setInt(1,rs.getInt(1)+1);
							stmt2.setInt(2,rs.getInt(2)+1);
							timeUsed=System.currentTimeMillis()-timeUsed;
							double newAvg = (timeUsed + rs.getDouble(3) * rs.getInt(2)) / ( rs.getInt(2) + 1); 
							stmt2.setDouble(3,newAvg);
							stmt2.setString(4,inputs[2]);
							stmt2.executeUpdate();
						} else {
							PreparedStatement stmt3 = conn.prepareStatement("UPDATE UserInfo SET played = ? WHERE name = ?");
							stmt3.setInt(1,rs.getInt(2)+1);
							stmt3.setString(2,rs.getString(4));
							stmt3.executeUpdate();
						}
					}
	            } else {
	            	Message jmsMessage = jmsHelper.createMessage("Wrong ans: "+result.toString());
					jmsMessage.setStringProperty("gamer1", inputs[2]);
					jmsMessage.setStringProperty("gamer2", "");
					jmsMessage.setStringProperty("gamer3", "");
					jmsMessage.setStringProperty("gamer4", "");
					broadcastMessage(topicSender, jmsMessage);
	            }
	            
	        }
	        catch (ScriptException e) {
	            e.printStackTrace();
	            Message jmsMessage = jmsHelper.createMessage("Wrong ans: Error");
				jmsMessage.setStringProperty("gamer1", inputs[2]);
				jmsMessage.setStringProperty("gamer2", "");
				jmsMessage.setStringProperty("gamer3", "");
				jmsMessage.setStringProperty("gamer4", "");
				broadcastMessage(topicSender, jmsMessage);
	        }
		}
		
	}
	
}
