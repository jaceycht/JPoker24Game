import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.TextMessage;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import java.rmi.*;
import java.rmi.registry.*;


public class JPoker24Game implements Runnable, MessageListener {

	private Count counter;
	
	private JMSHelper jmsHelper;
	private MessageProducer queueSender;
	private MessageConsumer topicReceiver;
	
	public JPoker24Game(String host) {
	    try {
	        Registry registry = LocateRegistry.getRegistry(host);
	        counter = (Count)registry.lookup("Counter");
	        jmsHelper = new JMSHelper(host);
	    } catch(Exception e) {
	        System.err.println("Failed accessing RMI: "+e);
	    }
	}

	public static void main(String[] args) {
	    SwingUtilities.invokeLater(new JPoker24Game(args[0]));
	}
	
	private String count;
	private JTextField loginName, password, registerName, registerPassword, registerConfirm;
	private JButton loginBtn, registerBtn, registerButton, cancelButton, btn1, btn2, btn3, btn4, newGameBtn;
	private String currentUser, currentPw;
	
	public void loginCount() {
		if(counter != null) {
	        try {
	            count = counter.count(currentUser,currentPw);
	        } catch (RemoteException e) {
	            System.err.println("Failed invoking RMI: ");
	        }
	    }
	}
	public void registerCount() {
		if(counter != null) {
	        try {
	            count = counter.count(currentUser,currentPw,currentPw);
	        } catch (RemoteException e) {
	            System.err.println("Failed invoking RMI: ");
	        }
	    }
	}
	public void logoutCount() {
		if(counter != null) {
	        try {
	            count = counter.count(currentUser);
	        } catch (RemoteException e) {
	            System.err.println("Failed invoking RMI: ");
	        }
	    }
	}
	
	public void run() {
		JFrame frame = new JFrame("Login");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		loginName = new JTextField();
		loginName.setPreferredSize( new Dimension(250, 30));
		password = new JTextField();
		password.setPreferredSize( new Dimension(250, 30));
		loginBtn = new JButton("Login");
		loginBtn.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
					String name = loginName.getText();
					String pw = password.getText(); 
					if (name.equals("")) {
						JOptionPane.showMessageDialog(null, "Login name should not be empty.", "Error", JOptionPane.ERROR_MESSAGE);
					} else {
						currentUser=name;
						currentPw = pw;
						loginCount();
						if (count.equals("invalid name")) {
							JOptionPane.showMessageDialog(null, "Invalid user. Please register.", "Error", JOptionPane.ERROR_MESSAGE);
						} else if (count.equals("invalid pw")) {
							JOptionPane.showMessageDialog(null, "Invalid password.", "Error", JOptionPane.ERROR_MESSAGE);
						} else if (count.equals("multiple")) {
							JOptionPane.showMessageDialog(null, "Multiple login is not allowed.", "Error", JOptionPane.ERROR_MESSAGE);
						} else {	
							frame.dispose();
							board();
						} 
					}
				} 
			});
		registerBtn = new JButton("Register");
		registerBtn.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
					frame.dispose();
					register();
				} 
			});
		
		JPanel panel = new JPanel(new GridLayout(4,1));
		panel.add(new JLabel("Login Name"));
		panel.add(loginName);
		panel.add(new JLabel("Password"));
		panel.add(password);
		
		JPanel btnPanel = new JPanel(new GridLayout(1,2));
		btnPanel.add(loginBtn);
		btnPanel.add(registerBtn);
		
		frame.add(panel, BorderLayout.PAGE_START);
		frame.add(btnPanel, BorderLayout.PAGE_END);
		frame.getRootPane().setBorder(new TitledBorder("Login"));
		
		frame.pack();
		frame.setVisible(true);
	}
	
	public void register() {
		JFrame frame = new JFrame("Register");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		registerName = new JTextField();
		registerName.setPreferredSize( new Dimension(250, 30));
		registerPassword = new JTextField();
		registerPassword.setPreferredSize( new Dimension(250, 30));
		registerConfirm = new JTextField();
		registerConfirm.setPreferredSize( new Dimension(250, 30));
		registerButton = new JButton("Register");
		registerButton.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
					String name = registerName.getText();
					String pw = registerPassword.getText(); 
					String confirm = registerConfirm.getText();
					if (name.equals("")) {
						JOptionPane.showMessageDialog(null, "Login name should not be empty.", "Error", JOptionPane.ERROR_MESSAGE);
					} else if (!pw.equals(confirm)) {
						JOptionPane.showMessageDialog(null, "Password and Confirm Password don't match.", "Error", JOptionPane.ERROR_MESSAGE);
					} else {
						currentUser=name;
						currentPw=pw;
						registerCount();
						if (count.equals("duplicated")) {
							JOptionPane.showMessageDialog(null, "Duplicate user name.", "Error", JOptionPane.ERROR_MESSAGE);
						} else {
							frame.dispose();
							board();
						}
					}
				} 
			});
		
		cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
					frame.dispose();
					run();
				} 
			});
		
		JPanel panel = new JPanel(new GridLayout(6,1));
		panel.add(new JLabel("Login Name"));
		panel.add(registerName);
		panel.add(new JLabel("Password"));
		panel.add(registerPassword);
		panel.add(new JLabel("Confirm Password"));
		panel.add(registerConfirm);
		
		JPanel btnPanel = new JPanel(new GridLayout(1,2));
		btnPanel.add(registerButton);
		btnPanel.add(cancelButton);
		
		frame.add(panel, BorderLayout.PAGE_START);
		frame.add(btnPanel, BorderLayout.PAGE_END);
		frame.getRootPane().setBorder(new TitledBorder("Register"));
		
		frame.pack();
		frame.setVisible(true);
	}
	
	JFrame frame = new JFrame("JPoker 24-Game");
	JPanel panel1, panel2, panel2b, panel2c, panel2cAns, panel2d, panel3;
	public void board() {

		frame.setPreferredSize(new Dimension (500,300));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		if(counter != null) {
	        try {
	            count = counter.count();
	        } catch (RemoteException e) {
	            System.err.println("Failed invoking RMI: ");
	        }
	    }
		String[] leaderBoard, leaderDetails;
		String data[][] = new String[10][5];
		leaderBoard = count.split(";");
		for (int i=0; i<leaderBoard.length; i++) {
			leaderDetails = leaderBoard[i].split(",");
			data[i][0] = Integer.toString(i+1);
			data[i][1] = leaderDetails[0];
			data[i][2] = leaderDetails[1];
			data[i][3] = leaderDetails[2];
			data[i][4] = leaderDetails[3]+"s";
		}
		panel3 = new JPanel();  
		String column[] = {"Rank","Player","Games Won","Games Played","Avg. winning time"};         
		JTable jt = new JTable(data,column);
		JScrollPane sp = new JScrollPane(jt);
		sp.getViewport().add(jt);
		sp.setPreferredSize(new Dimension(500,200));
		panel3.add(sp);	
		
		if(counter != null) {
	        try {
	            count = counter.count(currentUser,"","","");
	        } catch (RemoteException e) {
	            System.err.println("Failed invoking RMI: ");
	        }
	    }
		String[] detail;
		detail = count.split(",");
		panel1 = new JPanel(new GridLayout(10,1));
		panel1.add(new JLabel(currentUser));
		panel1.add(new JLabel("Number of wins: "+detail[1]));
		panel1.add(new JLabel("Number of games: "+detail[2]));
		panel1.add(new JLabel("Average time to win: "+detail[3]));
		panel1.add(new JLabel("Rank: "+detail[4]));
		
		panel2 = new JPanel(new GridLayout(5,1));
		newGameBtn = new JButton("New Game");
		newGameBtn.setVisible(true);
		newGameBtn.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				try {
					game();
				} catch (JMSException e1) {
					e1.printStackTrace();
				}
			}
		});
		panel2.add(newGameBtn);
		
		panel2b = new JPanel (new GridLayout(5,1));
		JLabel jl = new JLabel("Waiting for players...");
		panel2b.add(jl);
		
		btn1 = new JButton("User Profile");
		btn1.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				if(counter != null) {
			        try {
			            count = counter.count(currentUser,"","","");
			        } catch (RemoteException e2) {
			            System.err.println("Failed invoking RMI: ");
			        }
			    }
				String[] detail;
				detail = count.split(",");
				panel1 = new JPanel(new GridLayout(10,1));
				panel1.add(new JLabel(currentUser));
				panel1.add(new JLabel("Number of wins: "+detail[1]));
				panel1.add(new JLabel("Number of games: "+detail[2]));
				panel1.add(new JLabel("Average time to win: "+detail[3]));
				panel1.add(new JLabel("Rank: "+detail[4]));
				
			    try{frame.remove(panel2);}catch(Exception e1){}
			    try{frame.remove(panel2b);}catch(Exception e1){}
			    try{frame.remove(panel2c);}catch(Exception e1){}
			    try{frame.remove(panel2cAns);}catch(Exception e1){}
			    try{frame.remove(panel2d);}catch(Exception e1){}
			    try{frame.remove(panel3);}catch(Exception e2){}
				frame.add(panel1, BorderLayout.CENTER);
				frame.repaint();
				frame.getContentPane().invalidate();
				frame.getContentPane().validate();
				frame.pack();
				frame.setVisible(true);
			}
		});
		btn2 = new JButton("Play Game");
		btn2.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				try{frame.remove(panel1);}catch(Exception e1){}
			    try{frame.remove(panel2b);}catch(Exception e1){}
			    try{frame.remove(panel2c);}catch(Exception e1){}
			    try{frame.remove(panel2cAns);}catch(Exception e1){}
			    try{frame.remove(panel2d);}catch(Exception e1){}
			    try{frame.remove(panel3);}catch(Exception e2){}
				frame.add(panel2, BorderLayout.CENTER);
				frame.repaint();
				frame.getContentPane().invalidate();
				frame.getContentPane().validate();
				frame.pack();
				frame.setVisible(true);
			}
		});
		btn3 = new JButton("Leader Board");
		btn3.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				if(counter != null) {
			        try {
			            count = counter.count();
			        } catch (RemoteException e2) {
			            System.err.println("Failed invoking RMI: ");
			        }
			    }
				String[] leaderBoard, leaderDetails;
				String data[][] = new String[10][5];
				leaderBoard = count.split(";");
				for (int i=0; i<leaderBoard.length; i++) {
					leaderDetails = leaderBoard[i].split(",");
					data[i][0] = Integer.toString(i+1);
					data[i][1] = leaderDetails[0];
					data[i][2] = leaderDetails[1];
					data[i][3] = leaderDetails[2];
					data[i][4] = leaderDetails[3]+"s";
				}
				panel3 = new JPanel();  
				String column[] = {"Rank","Player","Games Won","Games Played","Avg. winning time"};         
				JTable jt = new JTable(data,column);
				JScrollPane sp = new JScrollPane(jt);
				sp.getViewport().add(jt);
				sp.setPreferredSize(new Dimension(500,200));
				panel3.add(sp);	
				
				try{frame.remove(panel1);}catch(Exception e1){}
			    try{frame.remove(panel2);}catch(Exception e2){}
			    try{frame.remove(panel2b);}catch(Exception e1){}
			    try{frame.remove(panel2c);}catch(Exception e1){}
			    try{frame.remove(panel2d);}catch(Exception e1){}
			    try{frame.remove(panel2cAns);}catch(Exception e1){}
				frame.add(panel3, BorderLayout.CENTER);
				frame.repaint();
				frame.getContentPane().invalidate();
				frame.getContentPane().validate();
				frame.pack();
				frame.setVisible(true);
			}
		});
		btn4 = new JButton("Logout");
		btn4.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				logoutCount();
				if (count.equals("ok")) {
					frame.dispose();
				} else {
					JOptionPane.showMessageDialog(null, "Logout error.", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		JPanel btnPanel = new JPanel(new GridLayout(1,4));
		btnPanel.add(btn1);
		btnPanel.add(btn2);
		btnPanel.add(btn3);
		btnPanel.add(btn4);
		
		frame.add(btnPanel, BorderLayout.PAGE_START);
		frame.add(panel1, BorderLayout.CENTER);
		frame.pack();
		frame.setVisible(true);
	}
	
	public void game() throws JMSException {
		try{frame.remove(panel1);}catch(Exception e1){}
		try{frame.remove(panel2);}catch(Exception e1){}
		try{frame.remove(panel2c);}catch(Exception e1){}
	    try{frame.remove(panel2cAns);}catch(Exception e1){}
	    try{frame.remove(panel2d);}catch(Exception e1){}
		try{frame.remove(panel3);}catch(Exception e1){}
		frame.add(panel2b, BorderLayout.CENTER);
		frame.repaint();
		frame.getContentPane().invalidate();
		frame.getContentPane().validate();
		frame.pack();
		frame.setVisible(true);
		
		queueSender = jmsHelper.createQueueSender();
		topicReceiver = jmsHelper.createTopicReader(currentUser);
		topicReceiver.setMessageListener(this);
		
		sendMessage();
	}

	public void sendMessage() {
		System.out.println(currentUser+" requesting new game.");
		Message message = null;
		try {
			message = jmsHelper.createMessage(currentUser);
		} catch (JMSException e) {
		}
		if(message != null) {
			try {
				queueSender.send(message);
			} catch (JMSException e) {
				System.err.println("Failed to send message");
			}
		}
	}
	
	public void sendAns(String ans, String[] cards, String name, String g1, String g2, String g3, String g4) {
		System.out.println("Sending ans = "+ans+"; cards = "+cards[0]+","+cards[1]+","+cards[2]+","+cards[3]+"; by "+name);
		Message message = null;
		try {
			message = jmsHelper.createMessage("Ans= "+ans+";"+cards[0]+","+cards[1]+","+cards[2]+","+cards[3]+";"+name+";"+g1+","+g2+","+g3+","+g4);
		} catch (JMSException e) {
		}
		if(message != null) {
			try {
				queueSender.send(message);
			} catch (JMSException e) {
				System.err.println("Failed to send message");
			}
		}
	}

	JLabel temp;
	@Override
	public void onMessage(Message jmsMessage) {
		String q = null, g1, g2, g3, g4;
		try {
			q = ((TextMessage) jmsMessage).getText();
			
			if (q.contains("Wrong ans: ")) {
				temp.setText(q.replaceAll("Wrong ans: ", "= "));
				frame.repaint();
				frame.getContentPane().invalidate();
				frame.getContentPane().validate();
				frame.pack();
				frame.setVisible(true);
			} else if (q.contains("Correct ans: ")) {
				String[] w = q.replaceAll("Correct ans: ","").split(";");
				panel2d = new JPanel(new GridLayout(3,1));
				panel2d.add(new JLabel("Winner: "+w[0]));
				panel2d.add(new JLabel(w[1]));
				JButton nextBtn = new JButton("Next game");
				nextBtn.addActionListener(new ActionListener() { 
					public void actionPerformed(ActionEvent e) {
						try {
							game();
						} catch (JMSException e1) {
							e1.printStackTrace();
						}
					}
				});
				panel2d.add(nextBtn);
				try{frame.remove(panel2c);}catch(Exception e1){}
				try{frame.remove(panel2cAns);}catch(Exception e1){}
				frame.add(panel2d, BorderLayout.CENTER);
				frame.repaint();
				frame.getContentPane().invalidate();
				frame.getContentPane().validate();
				frame.pack();
				frame.setVisible(true);
			} else {
				g1 =jmsMessage.getStringProperty("gamer1");
				g2 =jmsMessage.getStringProperty("gamer2");
				g3 =jmsMessage.getStringProperty("gamer3");
				g4 =jmsMessage.getStringProperty("gamer4");
				System.out.println("cards:"+q+";  gamers:"+g1+","+g2+","+g3+","+g4);
				
				if(counter != null) {
			        try {
			            count = counter.count(g1,g2,g3,g4);
			        } catch (RemoteException e) {
			            System.err.println("Failed invoking RMI: ");
			        }
			    }
				System.out.println(count);
				
				panel2c = new JPanel(new GridLayout(2,4,5,5));
				
				String[] info, info1, info2, info3, info4;
				JLabel jl1, jl2, jl3, jl4;
				Border b = BorderFactory.createLineBorder(Color.black, 3);
				info = count.split(";");
				info1 = info[0].split(",");
				jl1 = new JLabel("<html>"+info1[0]+"<br> Win: "+info1[1]+"/"+info1[2]+"<br> Avg: "+info1[3]+"s</html>");
				info2 = info[1].split(",");
				jl2 = new JLabel("<html>"+info2[0]+"<br> Win: "+info2[1]+"/"+info2[2]+"<br> Avg: "+info2[3]+"s</html>");
				if (info.length>2) {
					info3 = info[2].split(",");
					jl3 = new JLabel("<html>"+info3[0]+"<br> Win: "+info3[1]+"/"+info3[2]+"<br> Avg: "+info3[3]+"s</html>");
				} else {
					jl3 = new JLabel("");
				}
				if (info.length>3) {
					info4 = info[3].split(",");
					jl4 = new JLabel("<html>"+info4[0]+"<br> Win: "+info4[1]+"/"+info4[2]+"<br> Avg: "+info4[3]+"s</html>");
				}else {
					jl4 = new JLabel("");
				}
				jl1.setBorder(b);
				jl2.setBorder(b);
				jl3.setBorder(b);
				jl4.setBorder(b);
				panel2c.add(jl1);
				panel2c.add(jl2);
				panel2c.add(jl3);
				panel2c.add(jl4);
				
				String[] cards = q.replaceAll("X", "10").split(",");
				JLabel c1, c2, c3, c4;
				c1=new JLabel(cards[0], SwingConstants.CENTER);
				c2=new JLabel(cards[1], SwingConstants.CENTER);
				c3=new JLabel(cards[2], SwingConstants.CENTER);
				c4=new JLabel(cards[3], SwingConstants.CENTER);
				c1.setBackground(Color.BLUE);
				c1.setOpaque(true);
				c2.setBackground(Color.PINK);
				c2.setOpaque(true);
				c3.setBackground(Color.YELLOW);
				c3.setOpaque(true);
				c4.setBackground(Color.GREEN);
				c4.setOpaque(true);
				panel2c.add(c1);
				panel2c.add(c2);
				panel2c.add(c3);
				panel2c.add(c4);
				
				
				panel2cAns = new JPanel(new GridLayout(2,2));
				JLabel instruction = new JLabel("Type in your answer and press enter: ");
				temp = new JLabel("=");
				JTextField ans = new JTextField();
				ans.addKeyListener(new KeyAdapter() {
					public void keyPressed(KeyEvent e) {
						if(e.getKeyCode() == KeyEvent.VK_ENTER) {
							sendAns(ans.getText(), cards, currentUser, g1, g2, g3, g4);
						}
					}
				});
				panel2cAns.add(instruction);
				panel2cAns.add(new JLabel());
				panel2cAns.add(ans);
				panel2cAns.add(temp);
				
				try{frame.remove(panel2b);}catch(Exception e1){}
				frame.add(panel2c, BorderLayout.CENTER);
				frame.add(panel2cAns, BorderLayout.PAGE_END);
				frame.repaint();
				frame.getContentPane().invalidate();
				frame.getContentPane().validate();
				frame.pack();
				frame.setVisible(true);
				
			}
			
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}
}
