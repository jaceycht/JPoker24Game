import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Count extends Remote {
	String count(String name) throws RemoteException;
	String count(String name, String pw) throws RemoteException;
	String count(String name, String pw, String confirm_pw) throws RemoteException;
	String count(String g1, String g2, String g3, String g4) throws RemoteException;
	String count() throws RemoteException;
//	String count(String cards[] , String input) throws RemoteException, Exception;
}
